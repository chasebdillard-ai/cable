' Fetches one page of the catalog (file.json or file.json#key) and builds the RowList content tree.
sub init()
    m.top.functionName = "doWork"
end sub

sub doWork()
    ref = m.top.ref
    key = ""
    p = Instr(1, ref, "#")
    if p > 0
        key = Mid(ref, p + 1)
        ref = Left(ref, p - 1)
    end if
    url = m.top.base + ref
    body = fetch(url)
    if body = invalid
        body = fetch(url) ' one retry
    end if
    if body = invalid
        m.top.error = "network error"
        m.top.done = true
        return
    end if
    json = ParseJson(body)
    body = invalid
    if json = invalid
        m.top.error = "bad catalog data"
        m.top.done = true
        return
    end if
    if key <> ""
        json = json.Lookup(key)
        if json = invalid
            m.top.error = "section not found"
            m.top.done = true
            return
        end if
    end if
    root = CreateObject("roSGNode", "ContentNode")
    if json.sched <> invalid then json.rows = schedRows(json.sched)
    rows = json.rows
    if rows <> invalid
        for each r in rows
            items = r.i
            if items <> invalid and items.count() > 0
                rowNode = root.createChild("ContentNode")
                rowNode.title = r.t
                for each it in items
                    c = rowNode.createChild("ContentNode")
                    kind = it[0]
                    c.id = kind
                    c.url = it[1]
                    c.title = it[2]
                    if it.count() > 3 and it[3] <> invalid then c.description = it[3]
                    img = ""
                    if kind = "v"
                        img = it[1]
                    else if it.count() > 4 and it[4] <> invalid
                        img = it[4]
                    end if
                    if img <> ""
                        if Left(img, 4) <> "http" then img = "https://i.ytimg.com/vi/" + img + "/hqdefault.jpg"
                        c.HDPosterUrl = img
                    end if
                end for
            end if
        end for
    end if
    if json.t <> invalid then m.top.pageTitle = json.t
    if json.s <> invalid then m.top.pageSubtitle = json.s
    if root.getChildCount() = 0
        m.top.error = "empty section"
    else
        m.top.content = root
    end if
    m.top.done = true
end sub

function fetch(url as String) as Dynamic
    port = CreateObject("roMessagePort")
    ut = CreateObject("roUrlTransfer")
    ut.SetMessagePort(port)
    ut.SetCertificatesFile("common:/certs/ca-bundle.crt")
    ut.InitClientCertificates()
    ut.EnableEncodings(true)
    ut.RetainBodyOnError(false)
    ut.SetUrl(url)
    if not ut.AsyncGetToString() then return invalid
    msg = wait(20000, port)
    if type(msg) = "roUrlEvent"
        if msg.GetResponseCode() = 200 then return msg.GetString()
        return invalid
    end if
    ut.AsyncCancel()
    return invalid
end function

' Cable channel schedule -> On Now / Up Next rows. Same deterministic schedule as the website:
' position = (now - epoch) mod total duration, so the Roku shows what the site is airing right now.
function schedRows(sc as Object) as Object
    seq = sc.seq
    total = 0
    for each it in seq
        total = total + it[1]
    end for
    if total <= 0 then return []
    now = CreateObject("roDateTime").AsSeconds()
    ofs = (now - sc.epoch) mod total
    if ofs < 0 then ofs = ofs + total
    k = 0
    acc = 0
    while k < seq.count() - 1 and acc + seq[k][1] <= ofs
        acc = acc + seq[k][1]
        k = k + 1
    end while
    st = now - (ofs - acc)
    cur = seq[k]
    ago = Int((now - st) / 60)
    onNow = [["v", cur[0], cur[2], cur[3] + "   On since " + clock(st) + " (" + ago.toStr() + " min ago), until " + clock(st + cur[1]) + " - opens in YouTube from the start"]]
    nxt = []
    t = st + cur[1]
    j = k
    for n = 1 to 16
        j = (j + 1) mod seq.count()
        e = seq[j]
        nxt.push(["v", e[0], e[2], clock(t) + "  " + e[3]])
        t = t + e[1]
    end for
    return [{t: "On Now", i: onNow}, {t: "Up Next", i: nxt}]
end function

function clock(secs as Integer) as String
    dt = CreateObject("roDateTime")
    dt.FromSeconds(secs)
    dt.ToLocalTime()
    h = dt.GetHours()
    mi = dt.GetMinutes()
    ap = "a"
    if h >= 12 then ap = "p"
    h = h mod 12
    if h = 0 then h = 12
    ms = mi.toStr()
    if mi < 10 then ms = "0" + ms
    return h.toStr() + ":" + ms + ap
end function
