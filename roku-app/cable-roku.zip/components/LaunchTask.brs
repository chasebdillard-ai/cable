' Opens the official YouTube channel (id 837) on the video through Roku's External Control Protocol.
sub init()
    m.top.functionName = "doWork"
end sub

sub doWork()
    vid = m.top.videoId
    hosts = ["localhost", "127.0.0.1"]
    lastCode = 0
    lastReason = ""
    for each h in hosts
        r = request("http://" + h + ":8060/launch/837?contentId=" + vid + "&mediaType=movie", "POST")
        lastCode = r.code
        lastReason = r.reason
        if r.code >= 200 and r.code < 300
            m.top.status = "ok"
            m.top.done = true
            return
        end if
        if r.code = 403 or r.code = 404 then exit for
    end for
    ' Work out why: is ECP reachable at all, and is YouTube installed?
    q = request("http://localhost:8060/query/apps", "GET")
    if q.code = 200
        if Instr(1, q.body, "id=" + Chr(34) + "837" + Chr(34)) = 0
            m.top.status = "no_youtube"
        else if lastCode = 403
            m.top.status = "blocked"
        else
            m.top.status = "failed"
        end if
    else
        m.top.status = "blocked"
    end if
    if lastCode > 0
        m.top.detail = "HTTP " + lastCode.toStr()
    else
        m.top.detail = lastReason
    end if
    if m.top.detail = "" then m.top.detail = "no response"
    m.top.done = true
end sub

function request(url as String, method as String) as Object
    port = CreateObject("roMessagePort")
    ut = CreateObject("roUrlTransfer")
    ut.SetMessagePort(port)
    ut.SetUrl(url)
    ut.RetainBodyOnError(true)
    if method = "POST"
        ut.SetRequest("POST")
        ok = ut.AsyncPostFromString("")
    else
        ok = ut.AsyncGetToString()
    end if
    res = {code: 0, reason: "", body: ""}
    if not ok then return res
    msg = wait(8000, port)
    if type(msg) = "roUrlEvent"
        res.code = msg.GetResponseCode()
        res.reason = msg.GetFailureReason()
        s = msg.GetString()
        if s <> invalid then res.body = s
    else
        ut.AsyncCancel()
        res.reason = "timed out"
    end if
    return res
end function
