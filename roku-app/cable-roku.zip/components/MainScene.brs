' Page stack, feed loading and YouTube hand-off.
sub init()
    info = CreateObject("roAppInfo")
    m.base = info.GetValue("feed_base")
    m.brand = info.GetValue("brand_color")
    m.bgColor = info.GetValue("bg_color")
    m.textColor = info.GetValue("text_color")
    if m.brand = "" then m.brand = "0xE0313FFF"
    if m.bgColor = "" then m.bgColor = "0x0B0B0FFF"
    if m.textColor = "" then m.textColor = "0xFFFFFFFF"
    m.top.backgroundColor = m.bgColor
    m.top.backgroundURI = ""
    m.top.findNode("bg").color = m.bgColor
    m.top.findNode("bar").color = m.brand
    m.pages = m.top.findNode("pages")
    m.loading = m.top.findNode("loading")
    m.dialog = m.top.findNode("dialog")
    m.dialog.brandColor = m.brand
    m.dialog.observeField("closed", "onDialogClosed")
    m.stack = []
    m.feedTask = invalid
    m.launchTask = invalid
    openPage("home.json")
end sub

sub openPage(ref as String)
    if m.feedTask <> invalid then m.feedTask.control = "stop"
    m.loading.visible = true
    m.pendingRef = ref
    t = CreateObject("roSGNode", "FeedTask")
    t.base = m.base
    t.ref = ref
    t.observeField("done", "onFeedDone")
    m.feedTask = t
    t.control = "run"
end sub

sub onFeedDone()
    t = m.feedTask
    m.loading.visible = false
    if t = invalid then return
    if t.error <> "" or t.content = invalid
        if m.stack.count() = 0
            showDialog("Couldn't load the catalog", "The channel couldn't reach its catalog online (" + t.error + "). Check that the Roku is connected to the internet, then press OK to try again.", "retry")
        else
            showDialog("Couldn't open this section", "The section couldn't be loaded (" + t.error + "). Check the internet connection and try again.", "")
        end if
        return
    end if
    page = CreateObject("roSGNode", "PageView")
    page.brandColor = m.brand
    page.textColor = m.textColor
    page.pageTitle = t.pageTitle
    page.pageSubtitle = t.pageSubtitle
    page.content = t.content
    page.observeField("selectedItem", "onItemSelected")
    if m.stack.count() > 0 then m.stack.peek().visible = false
    m.pages.appendChild(page)
    m.stack.push(page)
    page.setFocus(true)
    m.feedTask = invalid
end sub

sub onItemSelected(ev as Object)
    item = ev.getData()
    if item = invalid then return
    if item.id = "p"
        openPage(item.url)
    else if item.id = "v"
        launchYouTube(item.url, item.title)
    else if item.id = "l"
        playLive(item)
    end if
end sub

' Live HLS channel (Right Now TV / COMET / Charge!): plays natively; on an error falls through the url list.
sub playLive(item as Object)
    m.player = m.top.findNode("player")
    m.liveItem = item
    m.liveUrls = item.url.Split("|")
    m.liveIdx = 0
    m.player.unobserveField("state")
    m.player.observeField("state", "onLiveState")
    m.top.findNode("liveTitle").text = item.title + "   LIVE"
    m.top.findNode("liveSub").text = "Up/Down: other live channels    Back: return to the menu"
    startLiveUrl()
end sub

sub startLiveUrl()
    c = CreateObject("roSGNode", "ContentNode")
    c.url = m.liveUrls[m.liveIdx]
    c.streamFormat = "hls"
    c.live = true
    c.title = m.liveItem.title
    m.player.content = c
    m.player.visible = true
    m.player.control = "play"
    m.player.setFocus(true)
    showLiveBar()
end sub

sub showLiveBar()
    bar = m.top.findNode("liveBar")
    bar.visible = true
    if m.barTimer = invalid
        m.barTimer = CreateObject("roSGNode", "Timer")
        m.barTimer.duration = 5
        m.barTimer.observeField("fire", "hideLiveBar")
    end if
    m.barTimer.control = "stop"
    m.barTimer.control = "start"
end sub

sub hideLiveBar()
    m.top.findNode("liveBar").visible = false
end sub

sub onLiveState()
    st = m.player.state
    if st = "error" or st = "finished"
        if m.liveIdx < m.liveUrls.count() - 1
            m.liveIdx = m.liveIdx + 1
            startLiveUrl()
        else
            stopLive()
            showDialog("Technical difficulties", m.liveItem.title + " isn't streaming right now. Please stand by and try again in a few minutes.", "")
        end if
    end if
end sub

sub stopLive()
    if m.player = invalid then return
    m.player.unobserveField("state")
    m.player.control = "stop"
    m.player.visible = false
    hideLiveBar()
    if m.stack.count() > 0 then m.stack.peek().setFocus(true)
end sub

' Up/Down while a live channel plays: next/previous live channel in the same row.
sub zapLive(dirn as Integer)
    row = m.liveItem.getParent()
    if row = invalid then return
    n = row.getChildCount()
    idx = 0
    for i = 0 to n - 1
        if row.getChild(i).isSameNode(m.liveItem) then idx = i
    end for
    idx = (idx + dirn + n) mod n
    playLive(row.getChild(idx))
end sub

sub launchYouTube(videoId as String, title as String)
    if m.launchTask <> invalid then return
    m.loading.text = "Opening YouTube..."
    m.loading.visible = true
    t = CreateObject("roSGNode", "LaunchTask")
    t.videoId = videoId
    t.observeField("done", "onLaunchDone")
    m.launchTask = t
    t.control = "run"
end sub

sub onLaunchDone()
    t = m.launchTask
    m.launchTask = invalid
    m.loading.visible = false
    m.loading.text = "Loading..."
    if t = invalid then return
    if t.status = "ok" then return
    if t.status = "no_youtube"
        showDialog("YouTube channel needed", "Videos play in the official YouTube channel. Add YouTube from the Roku Channel Store (Streaming Channels > Search > YouTube), then try again.", "")
    else if t.status = "blocked"
        showDialog("Allow this channel to open YouTube", "Videos play in the official YouTube channel, and this channel opens it for you over the Roku's local control port, which is turned off. To turn it on, go to Settings > System > Advanced system settings > Control by mobile apps and set Network access to Default or Permissive. Then try again. (Error " + t.detail + ")", "")
    else
        showDialog("Couldn't open YouTube", "This channel couldn't start the YouTube channel (" + t.detail + "). Make sure YouTube is installed and Settings > System > Advanced system settings > Control by mobile apps is enabled, then try again.", "")
    end if
end sub

sub showDialog(title as String, message as String, action as String)
    m.dialogAction = action
    m.dialog.title = title
    m.dialog.message = message
    m.dialog.visible = true
    m.dialog.setFocus(true)
end sub

sub onDialogClosed()
    m.dialog.visible = false
    if m.dialogAction = "retry"
        m.dialogAction = ""
        openPage("home.json")
        return
    end if
    if m.stack.count() > 0
        m.stack.peek().setFocus(true)
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false
    if m.player <> invalid and m.player.visible
        if key = "back"
            stopLive()
        else if key = "up" or key = "right"
            zapLive(1)
        else if key = "down" or key = "left"
            zapLive(-1)
        else
            showLiveBar()
        end if
        return true
    end if
    if key = "back"
        if m.dialog.visible then return true
        if m.feedTask <> invalid and m.stack.count() > 0
            m.feedTask.control = "stop"
            m.feedTask = invalid
            m.loading.visible = false
            m.stack.peek().setFocus(true)
            return true
        end if
        if m.stack.count() > 1
            page = m.stack.pop()
            m.pages.removeChild(page)
            prev = m.stack.peek()
            prev.visible = true
            prev.setFocus(true)
            return true
        end if
        return false ' top page: exit the channel
    end if
    return false
end function
