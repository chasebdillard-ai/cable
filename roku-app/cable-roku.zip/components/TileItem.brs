sub init()
    m.poster = m.top.findNode("poster")
    m.label = m.top.findNode("label")
end sub

sub onContent()
    c = m.top.itemContent
    if c = invalid then return
    m.label.text = c.title
    uri = c.HDPosterUrl
    if (c.id = "p" or c.id = "l") and Instr(1, uri, "ytimg.com") = 0 and Left(uri, 4) = "http" and Instr(1, uri, "tvmaze") = 0
        ' promotion / hub logo: show the whole logo, padded
        m.poster.loadDisplayMode = "scaleToFit"
        m.poster.loadWidth = 0
        m.poster.loadHeight = 0
        m.poster.translation = [40, 30]
        m.poster.width = 320
        m.poster.height = 165
    else
        ' YouTube hqdefault is 4:3 with the 16:9 picture letterboxed: draw it 400x300 and clip to 400x225
        m.poster.loadDisplayMode = "scaleToFill"
        m.poster.loadWidth = 480
        m.poster.loadHeight = 360
        m.poster.translation = [0, -37]
        m.poster.width = 400
        m.poster.height = 300
    end if
    m.poster.uri = uri
end sub

sub onFocus()
    if m.top.focusPercent > 0.5
        m.label.color = "0xFFFFFFFF"
    else
        m.label.color = "0xD8D8DCFF"
    end if
end sub
