sub init()
end sub

sub onText()
    m.top.findNode("dlgTitle").text = m.top.title
    m.top.findNode("dlgMsg").text = m.top.message
end sub

sub onColor()
    m.top.findNode("stripe").color = m.top.brandColor
    m.top.findNode("btn").color = m.top.brandColor
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return true
    if key = "OK" or key = "back"
        m.top.closed = true
        return true
    end if
    return true ' swallow everything else while open
end function
