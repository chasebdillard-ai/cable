' One catalog page: a header with the focused tile's details, then RowLists of tiles.
sub init()
    m.rows = m.top.findNode("rows")
    m.focusTitle = m.top.findNode("focusTitle")
    m.focusSub = m.top.findNode("focusSub")
    m.rows.observeField("rowItemFocused", "onFocusItem")
    m.rows.observeField("rowItemSelected", "onSelectItem")
    m.top.observeField("focusedChild", "onFocusChange")
end sub

sub onColors()
    b = m.top.brandColor
    if b <> ""
        m.top.findNode("accent").color = b
        m.rows.rowLabelColor = b
        m.rows.focusBitmapBlendColor = b
    end if
    t = m.top.textColor
    if t <> ""
        m.top.findNode("title").color = t
        m.focusTitle.color = t
    end if
end sub

sub onTitle()
    m.top.findNode("title").text = m.top.pageTitle
    m.top.findNode("subtitle").text = m.top.pageSubtitle
end sub

sub onContent()
    m.rows.content = m.top.content
    m.rows.jumpToRowItem = [0, 0]
    showDetails(0, 0)
end sub

sub onFocusChange()
    if m.top.hasFocus() then m.rows.setFocus(true)
end sub

sub onFocusItem()
    f = m.rows.rowItemFocused
    if f <> invalid and f.count() = 2 then showDetails(f[0], f[1])
end sub

function itemAt(r as Integer, c as Integer) as Dynamic
    content = m.rows.content
    if content = invalid then return invalid
    row = content.getChild(r)
    if row = invalid then return invalid
    return row.getChild(c)
end function

sub showDetails(r as Integer, c as Integer)
    it = itemAt(r, c)
    if it = invalid
        m.focusTitle.text = ""
        m.focusSub.text = ""
        return
    end if
    m.focusTitle.text = it.title
    s = it.description
    if it.id = "p"
        if s <> "" then s = s + "   "
        s = s + "Press OK to open"
    else if it.id = "l"
        if s <> "" then s = s + "   "
        s = s + "Press OK to watch live here"
    else
        if s <> "" then s = s + "   "
        s = s + "Press OK to watch on YouTube"
    end if
    m.focusSub.text = s
end sub

sub onSelectItem()
    f = m.rows.rowItemSelected
    if f = invalid or f.count() <> 2 then return
    it = itemAt(f[0], f[1])
    if it <> invalid then m.top.selectedItem = it
end sub
