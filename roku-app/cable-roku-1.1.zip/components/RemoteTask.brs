' Cable Remote listener for Roku (2026-11-21). Protocol = /workspace/work/cable/src/rlink.js (ntfy side):
'   command topic  "cbl" + first 32 hex of SHA-256("ntfy:" + key) + "c", state topic ... + "s", pairing topic "cable-pair-" + CODE.
'   Messages {"v":1,"f":..,"s":..,"ts":..,"d":{"c":[...]},"h":HMAC-SHA256(key, f|s|ts|d)}; unsigned, replayed (seq not newer) or stale (> 20 s old) are ignored.
sub init()
    m.top.functionName = "doWork"
end sub

sub doWork()
    m.port = CreateObject("roMessagePort")
    m.top.observeField("key", m.port)
    m.top.observeField("code", m.port)
    m.lastSeq = {}
    m.fid = "roku" + Left(CreateObject("roDeviceInfo").GetRandomUUID().Replace("-", ""), 10)
    m.fails = 0
    while true
        k = m.top.key
        c = m.top.code
        if k = "" and c = ""
            m.top.status = "idle"
            msg = wait(0, m.port)
        else
            listen(k, c)
        end if
    end while
end sub

function hexSha(s as String) as String
    d = CreateObject("roEVPDigest")
    d.Setup("sha256")
    ba = CreateObject("roByteArray")
    ba.FromAsciiString(s)
    return LCase(d.Process(ba))
end function

function hmacHex(k as String, s as String) as String
    h = CreateObject("roHMAC")
    kb = CreateObject("roByteArray")
    kb.FromAsciiString(k)
    if h.Setup("sha256", kb) <> 0 then return ""
    mb = CreateObject("roByteArray")
    mb.FromAsciiString(s)
    return LCase(h.Process(mb).ToHexString())
end function

' one streaming connection to ntfy.sh (both topics in one subscription); returns when it drops or the key/code changes
sub listen(k as String, c as String)
    topics = []
    m.cmdTopic = ""
    m.stTopic = ""
    m.pairTopic = ""
    if k <> ""
        base = Left(hexSha("ntfy:" + k), 32)
        m.cmdTopic = "cbl" + base + "c"
        m.stTopic = "cbl" + base + "s"
        topics.push(m.cmdTopic)
    end if
    if c <> ""
        m.pairTopic = "cable-pair-" + UCase(c)
        topics.push(m.pairTopic)
    end if
    m.top.status = "connecting"
    addr = CreateObject("roSocketAddress")
    addr.SetHostName("ntfy.sh")
    addr.SetPort(80)
    sock = CreateObject("roStreamSocket")
    sock.setSendToAddress(addr)
    if not sock.Connect() ' blocking connect first, then switch to readable notifications on the task's port
        sock.Close()
        backoff()
        return
    end if
    sock.setMessagePort(m.port)
    sock.notifyReadable(true)
    req = "GET /" + topics.join(",") + "/json HTTP/1.0" + Chr(13) + Chr(10) + "Host: ntfy.sh" + Chr(13) + Chr(10) + "User-Agent: CableRoku/1.1" + Chr(13) + Chr(10) + Chr(13) + Chr(10)
    sock.SendStr(req)
    buf = ""
    inBody = false
    seen = CreateObject("roTimespan")
    m.srvOff = 0
    while true
        msg = wait(5000, m.port)
        t = type(msg)
        if t = "roSGNodeEvent"
            if m.top.key <> k or m.top.code <> c then exit while
        else if t = "roSocketEvent"
            if sock.isReadable()
                n = sock.getCountRcvBuf()
                if n <= 0 then exit while ' closed by the server
                buf = buf + sock.ReceiveStr(n)
                seen.Mark()
                if not inBody
                    p = Instr(1, buf, Chr(13) + Chr(10) + Chr(13) + Chr(10))
                    if p > 0
                        if Instr(1, Left(buf, p), " 200 ") = 0 then exit while
                        buf = Mid(buf, p + 4)
                        inBody = true
                    end if
                end if
                if inBody
                    p = Instr(1, buf, Chr(10))
                    while p > 0
                        line = Left(buf, p - 1)
                        buf = Mid(buf, p + 1)
                        onLine(line, k)
                        p = Instr(1, buf, Chr(10))
                    end while
                end if
            end if
        end if
        if seen.TotalSeconds() > 100 then exit while ' ntfy keepalive is every 45 s
    end while
    sock.Close()
    m.top.status = "reconnecting"
    if m.top.key = k and m.top.code = c then backoff()
end sub

sub backoff()
    m.fails = m.fails + 1
    w = 2000 * m.fails
    if w > 30000 then w = 30000
    wait(w, m.port)
end sub

sub onLine(line as String, k as String)
    j = ParseJson(line)
    if j = invalid then return
    now = CreateObject("roDateTime").AsSeconds()
    if j.event = "open"
        if j.time <> invalid then m.srvOff = j.time - now
        m.top.status = "connected"
        m.fails = 0
        return
    end if
    if j.event <> "message" or j.message = invalid then return
    if j.time <> invalid and j.time < now + m.srvOff - 20 then return ' stale (replayed after a reconnect)
    if j.topic = m.pairTopic and m.pairTopic <> ""
        onPair(j.message, k)
    else if j.topic = m.cmdTopic and m.cmdTopic <> ""
        onCmd(j.message, k)
    end if
end sub

sub onPair(s as String, k as String)
    p = ParseJson(s)
    if p = invalid or p.t <> "pair" or p.p = invalid or k = "" then return
    nm = "your phone"
    if p.n <> invalid then nm = p.n
    body = "{" + q("t") + ":" + q("key") + "," + q("p") + ":" + q(p.p) + "," + q("k") + ":" + q(k) + "," + q("n") + ":" + q("Roku") + "," + q("tr") + ":" + q("n") + "}"
    if post("https://ntfy.sh/" + m.pairTopic, body, true) then m.top.paired = nm
end sub

sub onCmd(s as String, k as String)
    re = CreateObject("roRegex", "^\{" + Chr(34) + "v" + Chr(34) + ":1," + Chr(34) + "f" + Chr(34) + ":" + Chr(34) + "([^" + Chr(34) + "]+)" + Chr(34) + "," + Chr(34) + "s" + Chr(34) + ":([0-9]+)," + Chr(34) + "ts" + Chr(34) + ":([0-9]+)," + Chr(34) + "d" + Chr(34) + ":(.*)," + Chr(34) + "h" + Chr(34) + ":" + Chr(34) + "([0-9a-f]+)" + Chr(34) + "\}$", "s")
    mt = re.Match(s)
    if mt.count() < 6 then return
    f = mt[1]
    sq = mt[2]
    d = mt[4]
    if hmacHex(k, f + "|" + sq + "|" + mt[3] + "|" + d) <> mt[5] then return ' not signed with this TV's key
    last = m.lastSeq[f]
    if last <> invalid
        if Len(sq) < Len(last) or (Len(sq) = Len(last) and sq <= last) then return ' duplicate / replay
    end if
    m.lastSeq[f] = sq
    dd = ParseJson(d)
    if dd = invalid or dd.c = invalid then return
    for each c in dd.c
        if type(c) = "roString" or type(c) = "String" then runCmd(c, k)
    end for
end sub

sub runCmd(c as String, k as String)
    keys = {up: "Up", down: "Down", left: "Left", right: "Right", ok: "Select", back: "Back", info: "Info", pp: "Play", rw: "Rev", ff: "Fwd", chup: "Up", chdn: "Down", "vol+": "VolumeUp", "vol-": "VolumeDown", mute: "VolumeMute", exit: "Back", menu: "Back"}
    if c = "hello"
        sendState(k)
        return
    end if
    kk = keys[c]
    if kk = invalid then return ' guide / numbers / channel list: not on Roku yet
    post("http://localhost:8060/keypress/" + kk, "", false)
end sub

function q(s as String) as String
    s = s.Replace("\", "\\").Replace(Chr(34), "\" + Chr(34))
    out = ""
    for i = 1 to Len(s)
        ch = Mid(s, i, 1)
        a = Asc(ch)
        if a >= 32 and a < 127 then out = out + ch
    end for
    return Chr(34) + out + Chr(34)
end function

sub sendState(k as String)
    if m.stTopic = "" then return
    info = m.top.info
    if info = "" then info = "Cable on Roku"
    d = "{" + q("st") + ":{" + q("caps") + ":" + q("roku") + "," + q("dev") + ":" + q("Roku") + "," + q("on") + ":true," + q("title") + ":" + q(info) + "," + q("sub") + ":" + q("D-pad, OK, Back, play/pause and volume") + "}}"
    dt = CreateObject("roDateTime")
    ms = dt.GetMilliseconds()
    sq = dt.AsSeconds().toStr() + Right("00" + ms.toStr(), 3)
    h = hmacHex(k, m.fid + "|" + sq + "|" + sq + "|" + d)
    body = "{" + q("v") + ":1," + q("f") + ":" + q(m.fid) + "," + q("s") + ":" + sq + "," + q("ts") + ":" + sq + "," + q("d") + ":" + d + "," + q("h") + ":" + q(h) + "}"
    post("https://ntfy.sh/" + m.stTopic, body, false)
end sub

function post(url as String, body as String, nocache as Boolean) as Boolean
    p = CreateObject("roMessagePort")
    ut = CreateObject("roUrlTransfer")
    ut.SetMessagePort(p)
    ut.SetUrl(url)
    if Left(url, 5) = "https"
        ut.SetCertificatesFile("common:/certs/ca-bundle.crt")
        ut.InitClientCertificates()
    end if
    if nocache then ut.AddHeader("Cache", "no")
    ut.SetRequest("POST")
    if not ut.AsyncPostFromString(body) then return false
    msg = wait(6000, p)
    if type(msg) = "roUrlEvent"
        code = msg.GetResponseCode()
        return code >= 200 and code < 300
    end if
    ut.AsyncCancel()
    return false
end function
